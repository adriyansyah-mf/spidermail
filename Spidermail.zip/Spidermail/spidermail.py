
from bs4 import BeautifulSoup
from module.extractor import Extractor
from module.httpreq import HttpReq
from module.downloader import Downloader
from module.splitersmail import SplitersMail
from module.instachecker import Instachecker
from module.applechecker import AppleChecker
from colorama import Fore, Style, init
import requests
import requests_cache
import os
import json
import sys
import time
import platform
import subprocess as proses
import random

total_gained = 0
database_email = {}
sub_database = []
only_choose_email = "all"

#Color script
HEADER = Fore.LIGHTMAGENTA_EX
OKBLUE = Fore.LIGHTBLUE_EX
GREEN = Fore.LIGHTGREEN_EX
WARNING = Fore.LIGHTYELLOW_EX
FAIL = Fore.RED

#For colorama
init()

def clearScreen():
    if 'Linux' in platform.system():
        proses.call('clear', shell=True)
    elif "Windows" in platform.system():
        proses.call('cls', shell=True)

stripCode = "━"
def setStripCode():
    global stripCode

    if 'Linux' in platform.system():
        stripCode = "━"
    elif 'Windows' in platform.system():
        stripCode = "-"
    

def headers():
    clearScreen()
    print("\n")
    global stripCode
    
    if 'Linux' in platform.system():
        print("           {}╭━━━╮╱╱╱╱╱╭╮╱╱╱╱╱╱╱╱╱╱╱╭╮".format(WARNING))
        print("           ┃╭━╮┃╱╱╱╱╱┃┃╱╱╱╱╱╱╱╱╱╱╱┃┃")
        print("           ┃╰━━┳━━┳┳━╯┣━━┳━┳╮╭┳━━┳┫┃")
        print("           ╰━━╮┃╭╮┣┫╭╮┃┃━┫╭┫╰╯┃╭╮┣┫┃")
        print("           ┃╰━╯┃╰╯┃┃╰╯┃┃━┫┃┃┃┃┃╭╮┃┃╰╮")
        print("           ╰━━━┫╭━┻┻━━┻━━┻╯╰┻┻┻╯╰┻┻━╯")
        print("           ╱╱╱╱┃┃")
        print("           ╱╱╱╱╰╯")
    print("")
    print("     {}[{}{}{}]     {}Spider Email Crawler    {}[{}{}{}]".format(WARNING, OKBLUE, stripCode, WARNING, OKBLUE, WARNING, OKBLUE, stripCode,WARNING))
    print("     {}[{}{}{}]  {}made by: {}Yusril Rapsanjani {}[{}{}{}]".format(WARNING, OKBLUE, stripCode, WARNING, OKBLUE, HEADER, WARNING, OKBLUE, stripCode, WARNING))
    print("     {}[{}{}{}]        {}Version: {}1.0.1       {}[{}{}{}]".format(WARNING, OKBLUE, stripCode, WARNING, OKBLUE, HEADER, WARNING, OKBLUE, stripCode, WARNING))
    print("     {}[{}{}{}]       {}Codename: {}yurani      {}[{}{}{}]".format(WARNING, OKBLUE, stripCode, WARNING, OKBLUE, HEADER, WARNING, OKBLUE, stripCode, WARNING))
    print("     {}[{}{}{}]     {}Sites: {}www.yurani.me    {}[{}{}{}]".format(WARNING, OKBLUE, stripCode, WARNING, OKBLUE, HEADER, WARNING, OKBLUE, stripCode, WARNING))
    print("     {}[{}{}{}]{}[{}{}{}]".format(WARNING, OKBLUE, stripCode, WARNING, stripCode*29,OKBLUE, stripCode, WARNING))
    print("")

def RemovePreviousFiles(file_ident, maxcount):
    print("\n     {}[*]{} Menghapus previous data...".format(FAIL, WARNING))
    for x in range(0, maxcount):
        try:
            os.remove("{}-{}.xlsx".format(str(file_ident), str(x)))
        except:
            continue
    print("     {}[INFO]{} Berhasil menghapus...".format(OKBLUE, WARNING))

def ValidateEmail():
    global sub_database
    global database_email
    global total_gained
    global only_choose_email

    database_email['Email_Data'] = sub_database

    print("     {}[+]{} Total Email: {}{}{} email address...".format(GREEN, WARNING, GREEN, str(total_gained), WARNING))
    time.sleep(2)
    path = input("     [?] Masukkan path lokasi penyimpanan email: ")
    if path == "":
        from os.path import expanduser
        home = expanduser("~")
        if 'Linux' in platform.system():
            path = home + "/"
        elif 'Windows' in platform.system():
            path = "C:\\Users"

    #Spliting emails
    spliter = SplitersMail(database_email, path, only_choose_email)
    spliter.Splits()


def ExtractEmail(file_ident, maxs):
    global total_gained
    global sub_database
    global only_choose_email
    
    print("     {}[*]{} Memulai proses extract email...".format(HEADER, WARNING))
    for index in range(1, maxs+1):
        try:
            extract = Extractor("{}-{}.xlsx".format(str(file_ident), index), only_choose_email)
            email_data = extract.Extract()

            #Store data to dictionary
            for x in range(0, len(email_data)):
                total_gained += 1

                temp_dict = {}
                temp_dict["no"] = total_gained
                temp_dict["email"] = email_data[x]
                sub_database.append(temp_dict)

            print("     {}[+]{} Mendapatkan {}{}{} email address...".format(GREEN, WARNING, GREEN, str(len(email_data)), WARNING))
        except:
            continue

def RetrieveEmail(email_data):
    global total_gained
    global sub_database

    for x in range(0, len(email_data)):
        total_gained += 1

        temp_dict = {}
        temp_dict["no"] = total_gained
        temp_dict["email"] = email_data[x]
        sub_database.append(temp_dict)

def bingSearch(url, maxPage, tipePencarian, pathGecko):
    pageNumber = 1
    global total_gained

    #Merayap laman page sampai maksimum page yang ditentukan.
    for x in range(0, maxPage):
        #Next url yang mau di crawling
        next_url = url + "&first={}".format(str(pageNumber))

        #Getting HTTP Response
        print("\n     {}[INFO]{} Bersiap untuk menjelajah bagian {}/{}...".format(OKBLUE, WARNING, str(x+1), str(maxPage)))
        print("     {}[INFO]{} Mengirim spider untuk menjelajah...".format(OKBLUE, WARNING))
        httpReq = HttpReq(pathGecko)
        content = httpReq.getContent(next_url)

        #Parsing element dari content untuk mendapatkan l class
        soup = BeautifulSoup(content, 'html.parser')
        doc = soup.findAll("li", class_="b_algo")
        #Berfungsi untuk perhitungan email terextract
        count = 1

        #Random number for file
        file_ident = random.randint(0, 1000)

        if tipePencarian == "2":
            print("     {}[INFO]{} Spider memprediksi {} url untuk diunduh...\n".format(OKBLUE, WARNING, str(len(doc))))
            #Looping semua l class yang diduga mengandung link
            for _doc in doc:        
                #Mencari element a href dari l class
                for link in _doc.findAll("a", href=True):
                    try:
                        #Mengambil property href pada element
                        doclink = link['href']
                        #Jika link mengandung string .xlsx
                        if 'officeapps.live.com' not in doclink:
                            print("     {}[*]{} Mengunduh data... [{}]".format(GREEN, WARNING,str(count)), end='\r')

                            #Mendownload data ke local disk
                            downloader = Downloader()
                            downloader.Download(doclink, str(file_ident) + "-" + str(count) + ".xlsx")
                            print("     {}[*]{} Mengunduh data... [{}] => {}Success".format(GREEN, WARNING,str(count), GREEN))
                            count += 1
                    except Exception:
                        print("     {}[*]{} Mengunduh data... [{}] => {}Failure".format(GREEN, WARNING,str(count), FAIL))
                        continue

            print("     {}[INFO]{} Pengunduhan data selesai...\n".format(OKBLUE, WARNING))
            ExtractEmail(file_ident, count)

            RemovePreviousFiles(file_ident, count)
        
        elif tipePencarian == "1":
            gained = 0
            print("     {}[*]{} Memulai proses extract email...".format(HEADER, WARNING))
            for _doc in doc:
                #Mencari element a href dari l class
                for link in _doc.findAll("a", href=True):
                    try:
                        linktext = link.text
                        
                        extract = Extractor()
                        email_data = extract.RetrieveMail(linktext)

                        #Store email to json
                        RetrieveEmail(email_data)
                        gained += len(email_data)

                    except Exception:
                        continue
           
            caption = soup.findAll("div", class_="b_caption")
            for capt in caption:
                element_full = ""
                for p_element in capt.find("p"):
                    el = str(p_element).replace("<strong>", "").replace("</strong>", "")
                    element_full += el
                
                extract = Extractor()
                email_data = extract.RetrieveMail(element_full)

                #Store email to json
                if email_data:
                    RetrieveEmail(email_data)
                    gained += len(email_data)   
            
            print("     {}[+]{} Mendapatkan {}{}{} email address...".format(GREEN, WARNING, GREEN, str(gained), WARNING))

    
        pageNumber += 10

    #Proses Validate email
    print("\n     {}[INFO]{} Proses crawling email selesai...".format(OKBLUE, WARNING))
    ValidateEmail()

def getGeckoPath():
    print("\n     [INFO] Silahkan periksa versi bit sistem operasimu")
    architecture = input("     [?] Masukkan OS Architecture [32/64]: ")
    if architecture == "":
        architecture = "64"
    basePath = os.getcwd()

    if 'Linux' in platform.system():
        pathGecko = basePath + "/gecko/linux/"
        #Detect bit
        if '64' in architecture:
            pathGecko += "64/geckodriver"
        elif '32' in architecture:
            pathGecko += "32/geckodriver"
        
    elif 'Windows' in platform.system():
        pathGecko = basePath + "\\gecko\\windows\\"
        #Detect bit
        if '64' in architecture:
            pathGecko += "64\\geckodriver.exe"
        elif '32' in architecture:
            pathGecko += "32\\geckodriver.exe"

    return pathGecko

def CheckerInstagram():
    filepath = input("     [?] Masukkan mail list path: ")
    print("\n     {}".format(stripCode*38))
    print("     1. Check by only email")
    print("     2. Check by email and password [Format: email:password]")
    choose = input("     [?] Silahkan pilih jenis checker: ")


    print("\n     {} {} {}".format(stripCode*15,'L I V E', stripCode*15))
    #Get mail list
    with open(filepath, "r") as f:
        maillist = f.readlines()

    count = 0
    valid_list = []
    for mail in maillist:
        count += 1
        isValid = False
        try:
            mail = mail.replace("\n", "")
            #Checker without password
            if choose == "1":
                insta = Instachecker()
                isValid = insta.isValid(mail)

            #Checker with password
            elif choose == "2":
                insta = Instachecker()
                
                #Spliting for email and password
                spliter = mail.split(":")
                isValid = insta.isValid(spliter[0], spliter[1])

            if isValid == True:
                output = "     {}[{}{} {}/ {}{}{}] {}{} => {}LIVE!".format(OKBLUE, GREEN, str(count), OKBLUE, WARNING, str(len(maillist)), OKBLUE, WARNING, mail, GREEN)
                print(output)
                valid_list.append(mail)
            else:
                output = "     {}[{}{} {}/ {}{}{}] {}{} => {}DIE!".format(OKBLUE, GREEN, str(count), OKBLUE, WARNING, str(len(maillist)), OKBLUE, WARNING, mail, FAIL)
                print(output)
        except:
            continue

    print("\n     {}[+]{} Mendapatkan {}{}{} valid email...".format(GREEN, WARNING, GREEN, str(len(valid_list)), WARNING))
    savePath = input("{}     [?] Masukkan lokasi simpan valid instagram [ex: /home/yurani/insta.txt]: ".format(WARNING))
    if savePath != "":
        for valid in valid_list:
            with open(savePath, "a") as f:
                f.write(valid + "\n")
                f.close()

    print("\n     {}[INFO]{} Berhasil menyimpan valid instagram => {}".format(OKBLUE, WARNING, savePath))

def headerApple():
    print("         {}╭━━━╮╱╱╱╱╱╭╮╱╱╱╭━━━┳╮╱╱╱╱╭╮".format(GREEN))
    print("         ┃╭━╮┃╱╱╱╱╱┃┃╱╱╱┃╭━╮┃┃╱╱╱╱┃┃")
    print("         ┃┃╱┃┣━━┳━━┫┃╭━━┫┃╱╰┫╰━┳━━┫┃╭┳━━┳━╮")
    print("         ┃╰━╯┃╭╮┃╭╮┃┃┃┃━┫┃╱╭┫╭╮┃╭━┫╰╯┫┃━┫╭╯")
    print("         ┃╭━╮┃╰╯┃╰╯┃╰┫┃━┫╰━╯┃┃┃┃╰━┫╭╮┫┃━┫┃")
    print("         ╰╰╯╱╰┫╭━┫╭━┻━┻━━┻━━━┻╯╰┻━━┻╯╰┻━━┻╯")
    print("          ╱╱╱╱┃┃╱┃┃")
    print("          ╱╱╱╱╰╯╱╰╯")
    print("")
    print("       {}[{}APPLE ACCOUNT CHECKER{}]{}".format(stripCode*5, OKBLUE, GREEN, stripCode*5))
    print("      {}created by {}Yusril Rapsanjani {}& {}Akemi".format(WARNING, GREEN, WARNING, GREEN))
    print("     {}{}".format(WARNING, stripCode*38))

def getAppleHeader(pathGecko):
    #Apple url
    url = 'https://appleid.apple.com/account'
    #Downloading page source Apple
    httpReq = HttpReq(pathGecko)
    content = httpReq.getContent(url)

    #Get credentials data
    apple = AppleChecker(content)
    scnt = apple.getScnt()
    apikey = apple.getApikey()
    sessionID = apple.getSessionID()

    #Header for requests
    headers = {
        'scnt': scnt,
        'X-Apple-Api-Key': apikey,
        'X-Apple-ID-Session-Id': sessionID,
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.67 Safari/537.36',
        'Content-Type': 'application/json',
        'Accept': 'application/json, text/javascript, */*; q=0.01',
    }
    return headers

def isValid(header, email):
    requests_cache.install_cache("spidermail")
    url = 'https://appleid.apple.com/account/validation/appleid'
    data = '{"emailAddress":"(email)"}'
    data = data.replace("(email)", email)

    response = requests.post(url, headers=header, data=data, timeout=10)
    return response.text

def ApelChecker():
    clearScreen()
    headerApple()

    filepath = input("     [?] Masukkan mail list path: ")
    if os.path.exists(filepath):
        #Get mail list
        with open(filepath, "r") as f:
            maillist = f.readlines()

        live_list = []
        count = 0

        pathGecko = getGeckoPath()

        print("     {}[INFO]{} Mengirim spider untuk mencari Session Key...".format(OKBLUE, WARNING))
        headers = getAppleHeader(pathGecko)

        print("\n     {} {} {}".format(stripCode*15,'L I V E', stripCode*15))
        for mail in maillist:
            try:
                count += 1
                mail = mail.replace("\n", "")
                dataStatus = isValid(headers, mail)
                status = json.loads(dataStatus)

                #Check status live
                if status['used'] == True:
                    output = "     {}[{}{} {}/ {}{}{}] {}{} => {}LIVE!".format(OKBLUE, GREEN, str(count), OKBLUE, WARNING, str(len(maillist)), OKBLUE, WARNING, mail, GREEN)
                    print(output)
                    live_list.append(mail)
                else:
                    output = "     {}[{}{} {}/ {}{}{}] {}{} => {}DIE!".format(OKBLUE, GREEN, str(count), OKBLUE, WARNING, str(len(maillist)), OKBLUE, WARNING, mail, FAIL)
                    print(output)

            except Exception as e:
                print("     {}[INFO]{} Mengirim spider untuk mencari Session Key...".format(OKBLUE, WARNING))
                headers = getAppleHeader(pathGecko)
                continue
        
        print("\n     {}[+]{} Mendapatkan {}{}{} LIVE Apple".format(GREEN, WARNING, GREEN, str(len(live_list)), WARNING))
        savePath = input("{}     [?] Masukkan lokasi simpan LIVE Apple [ex: /home/yurani/apple.txt]: ".format(WARNING))
        if savePath != "":
            for valid in live_list:
                with open(savePath, "a") as f:
                    f.write(valid + "\n")
                    f.close()

        print("\n     {}[INFO]{} Berhasil menyimpan LIVE Apple => {}".format(OKBLUE, WARNING, savePath))
    else:
        print("\n     {}[FAILED]{} Mail list tidak ditemukan!".format(FAIL, WARNING))

#Default keyword
#@gmail.com filetype:xlsx indonesia PT
if __name__ == "__main__":
    
    setStripCode()
    headers()


    print("     1. Pencarian by spesifik web")
    print("     2. Pencarian by dokumen [Recommended]")
    print("     3. {}Instagram Checker{}".format(GREEN, WARNING))
    print("     4. {}Apple Checker{}".format(GREEN, WARNING))
    print("     5. Exit")
    print("     {}".format(stripCode*38))

    tipePencarian = input("     [?] Pilih tipe pencarian [1-4]: ")
    print("")
    if tipePencarian == "1" or tipePencarian == "2" :

        #Get input for keyword and site
        if tipePencarian == "2":
            keyword = input("     [?] Masukkan keyword pencarian: ")
        elif tipePencarian == "1":
            site = input("     [?] Masukkan site target [ex: twitter.com]: ")

        #Get input for mail pattern
        mailpattern = input("     [?] Masukkan mail pattern [ex: @gmail.com]: ")
        if mailpattern == "":
            mailpattern = "@gmail.com"

        #Get input for target extract email
        only_choose_email = input("     [?] Email apa yang ingin diextract? [ex: @gmail|@yahoo] [Default: all]: ")
        if only_choose_email == "":
            only_choose_email = "all"

        #Get input maximum load page
        page = input("     [?] Berapa maximum page yang mau diload?: ")
        max_page = 0
        try:
            max_page = int(page)
        except:
            print("     [x] Max page tidak valid!")
        
        #Default engine to use
        engine = 'Bing'

        if engine == 'Bing':
            pathGecko = getGeckoPath()

            if tipePencarian == "2":
                if keyword != "":
                    url = 'https://www.bing.com/search?q={} filetype:xlsx {}'.format(mailpattern, keyword)
                    bingSearch(url, max_page, "2", pathGecko)
                else:
                    print("     [x] Maaf keyword kamu kosong")
            elif tipePencarian == "1":
                if site != "":
                    url = 'https://www.bing.com/search?q=site:{} {}'.format(site, mailpattern)
                    bingSearch(url, max_page, "1", pathGecko)
                else:
                    print("     [x] Maaf silahkan isi site")

    elif tipePencarian == "3":
        CheckerInstagram()

    elif tipePencarian == "4":
        ApelChecker()

    else:
        sys.exit()
