import requests,json

class Instachecker():

  headers = {
      'origin': 'https://www.instagram.com',
      # 'accept-encoding': 'gzip, deflate, br',
      # 'accept-language': 'en-US,en;q=0.9',
      # 'x-requested-with': 'XMLHttpRequest',
      'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.67 Safari/537.36',
      # 'cookie': 'mid=XCYT-AAEAAGU634CHW61m4gAt_1G; mcd=3; shbid=3158; shbts=1546358834.1619763; rur=PRN; csrftoken=x5Svc53KMrC0DJOEBCYGKBAxOroQwfqG; urlgen="{\\"116.206.15.1\\": 45727}:1geMa1:WmVpYP44lF7nEczCkWXU1y1D0EE"',
      'x-csrftoken': 'x5Svc53KMrC0DJOEBCYGKBAxOroQwfqG',
      # 'x-instagram-ajax': '715dcf29ace5',
      # 'content-type': 'application/x-www-form-urlencoded',
      # 'accept': '*/*',
      # 'referer': 'https://www.instagram.com/accounts/login/',
      # 'authority': 'www.instagram.com',
  }


  def GetResponse(self, data):
    response = requests.post('https://www.instagram.com/accounts/login/ajax/', headers=self.headers, data=data)
    result = json.loads(response.text)

    isValid = result['user']
    return isValid

  def isValid(self, email, password=None):
    data = {
      'username': '{}'.format(email),
      'password': '{}'.format(password),
      'queryParams': '{}'
    }

    return self.GetResponse(data)