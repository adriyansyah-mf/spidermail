import requests
import requests_cache

class Downloader():

    def Download(self, url, filename):
        requests_cache.install_cache("spidermail")
        r = requests.get(url, timeout=4, stream=True)
        if r.status_code == 200:
            with open(filename, 'wb') as f:
                f.write(r.content)
                f.close()