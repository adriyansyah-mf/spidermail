import json
import os
from email_validator import validate_email, EmailNotValidError
import time
from colorama import Fore, Style, init
import platform

class SplitersMail():
    #Color script
    HEADER = Fore.LIGHTMAGENTA_EX
    OKBLUE = Fore.LIGHTBLUE_EX
    GREEN = Fore.LIGHTGREEN_EX
    WARNING = Fore.LIGHTYELLOW_EX
    FAIL = Fore.RED
    
    stripCode = "━"
    def setStripCode(self):
        if 'Linux' in platform.system():
            self.stripCode = "━"
        elif 'Windows' in platform.system():
            self.stripCode = "-"

    def __init__(self, data, path, only_choose_email):
        self.data = data
        self.path = path
        self.only_choose_email = only_choose_email
        init()
        self.setStripCode()

    def VerifyMail(self, value, filename, name):
        
        try:
            valid_list = []

            #Removing duplicate email
            maillist = list(set(value))
            count = 0
            print("     {} {} {}".format(self.stripCode*15,name, self.stripCode*15))

            for mail in maillist:
                try:
                    count += 1
                    isValid = validate_email(mail.replace("\n", ""))
                    v = isValid["email"]
                    valid_list.append(v)
                    output = "     {}[{}{} {}/ {}{}{}] {}{} => {}Active!".format(self.OKBLUE, self.GREEN, str(count), self.OKBLUE, self.WARNING, str(len(maillist)), self.OKBLUE, self.WARNING, v, self.GREEN)
                    print(output)
                    
                except:
                    continue

            print("     {}[INFO]{} Total active email in {}: {} emails\n".format(self.OKBLUE, self.WARNING, filename, str(len(valid_list))))
            self.WriteoutValid(valid_list, filename)
        except:
            pass

    def WriteoutValid(self, data, filename):
        try:
            os.makedirs(self.path + "/valid")
    
        except:
            pass

        for email in data:
            if os._exists(self.path + '/valid/' + filename):
                if email not in open(self.path + '/valid/' + filename).read():
                    with open(self.path + "/valid/" + filename, "a") as f:
                        f.write(email.lower() + "\n")
                        f.close()
            else:
                with open(self.path + "/valid/" + filename, "a") as f:
                    f.write(email.lower() + "\n")
                    f.close()

    def Writeout(self, data, filename):
        try:
            os.makedirs(self.path)
        except:
            pass

        for email in data:
            #If email not exists
            if os._exists(self.path + filename):
                if email not in open(self.path + "/" + filename).read():
                    with open(self.path + "/" +  filename, "a") as f:
                        f.write(email.lower() + "\n")
                        f.close()
            else:
                with open(self.path + "/" + filename, "a") as f:
                        f.write(email.lower() + "\n")
                        f.close()

    def SearchPattern(self, data):
        maillist = {}

        if self.only_choose_email.lower() == "all":
            self.only_choose_email = "@gmail|@yahoo|@hotmail|@aol|@tld"

        filtermail = self.only_choose_email.split("|")
        
        for filters in filtermail:
            tmp_mail = []
            for email in data['Email_Data']:
                if filters in email['email']:
                    tmp_mail.append(email['email'])
                else:
                    if '@tld' in filters and '@yahoo' not in email['email'] and '@gmail' not in email['email'] and '@hotmail' not in email['email'] and '@aol' not in email['email']:
                        tmp_mail.append(email['email'])

            maillist[filters] = tmp_mail 

        for key, value in maillist.items():
            self.Writeout(value, key + ".txt")   

        print("     [WARNING] Jumlah email yang besar akan memakan waktu saat validasi")
        time.sleep(3)
        answer = input("     [?] Anda yakin ingin melakukan validasi email? [y/n]: ")
        if answer.lower() == "y":
            print("\n     {}[*]{} Memulai proses validasi email... ".format(self.GREEN, self.WARNING))
            time.sleep(2)

            for key, value in maillist.items():
                header = ""
                for x in range(0, len(key)):
                    head = key[x].replace("@", "")
                    header += "{} ".format(head.upper())
                     
                self.VerifyMail(value, key + ".txt", header)

            print("     {}[INFO]{} Proses validasi selesai...".format(self.OKBLUE, self.WARNING,))

        print("     {}[INFO]{} Lokasi output => {}".format(self.OKBLUE, self.WARNING, self.path))
        print("     {}[INFO]{} Spider telah berhasil dimatikan...".format(self.OKBLUE, self.WARNING,))
        
    def Splits(self):
        self.SearchPattern(self.data)

