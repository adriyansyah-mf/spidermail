import xlrd
import re

class Extractor():

    def __init__(self, path=None, only_choose_email="all"):
        self.path = path
        self.only_choose_email = only_choose_email

    def Extract(self):
        sheet_data = []
        wb = xlrd.open_workbook(self.path)
        p = wb.sheet_names()
        
        #Looping any sheet
        for y in p:
            sh = wb.sheet_by_name(y)
            
            for rownum in range(sh.nrows):
                sheet_data.append((sh.row_values(rownum)))

        found_list = []
        for i in range(0, len(sheet_data)):        #@leeyurani
            for data in sheet_data[i]:             #Code for better life!
                try:
                    if '@' in data:
                        match = re.findall(r'[\w\.-]+@[\w\.-]+', data)
                        for emailMatch in match:
                            #Filtering email by mail pattern
                            if self.only_choose_email == 'all':
                                found_list.append(emailMatch)
                            else:
                                filtermail = self.only_choose_email.split("|")
                                for mail in filtermail:
                                    if mail in emailMatch:
                                        found_list.append(emailMatch)
                except:
                    continue

        return found_list

    def sendToFile(self, datalist):
        for data in datalist:
            with open("email-output.txt", "a") as f:
                f.write(data + "\n")
                f.close()

    def RetrieveMail(self, data):
        if '@' in data:
            match = re.findall(r'[\w\.-]+@[\w\.-]+', data)
            email_found = []
            for emailMatch in match:
                email_found.append(emailMatch)

            return email_found

        

