import re

class AppleChecker():

    def __init__(self, data):
        self.data = data

    def getScnt(self):
        pattern = re.findall("scnt: '(.*)'\,", self.data)
        return pattern[0]

    def getApikey(self):
        pattern = re.findall("apiKey: '(.*)'\,", self.data)
        return pattern[0]

    def getSessionID(self):
        pattern = re.findall("sessionId: '(.*)'\,", self.data)
        return pattern[0]

