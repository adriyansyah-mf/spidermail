from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from pyvirtualdisplay import Display
import requests_cache
import platform

class HttpReq():

    def __init__(self, geckoPath):
        self.geckoPath = geckoPath

    def getContent(self, url):
        requests_cache.install_cache("spidermail")

        #Detect os 
        system_os = platform.system()

        #We will use virtual display if os is Linux
        if 'Linux' in system_os:
            display = Display(visible=0, size=(800, 600))
            display.start()

        caps = DesiredCapabilities().FIREFOX
        caps["pageLoadStrategy"] = "eager" 
        driver = webdriver.Firefox(desired_capabilities=caps, executable_path=self.geckoPath)

        driver.get(url)
        content = driver.page_source
        driver.quit()

        #Stopping service
        if 'Linux' in system_os:
            display.stop()

        return content