apt-get update
apt-get install firefox
apt-get install xvfb
pip install -r requirements.txt
pip3 install -r requirements.txt
chmod -R 777 gecko
rm -R requirements.txt
rm -R setup.sh
chmod +x spidermail.py
python3 spidermail.py
